/* Brity 2.1.98 prototype. Prepend before dist/4902.prod.js chunk registration.
 * No user data, filesystem, networking or IPC implementation is included here.
 * The host supplies the existing local archive bridge in the renderer world.
 */
(function(root, build) {
  const api = build();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else api.install(root);
})(typeof globalThis === 'object' ? globalThis : this, function() {
  'use strict';
  const PREFIX = 'goe-local:';
  const CHUNK = 'webpackChunkbrity_teams_desktop_client';
  const MANAGER = 59165;
  const escapeHTML = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const localId = s => typeof s === 'string' && s.startsWith(PREFIX);
  function containsLocal(value, seen = new Set()) {
    if (localId(value)) return true;
    if (!value || typeof value !== 'object' || seen.has(value)) return false;
    seen.add(value);
    return Object.values(value).some(v => containsLocal(v, seen));
  }
  function makeHooks({read, report = () => {}, getVM, getDetailVM, pageSize = 50}) {
    const sessions = new Map();
    let records = new Map();
    const notify = (status, count) => {try { report({status, recordCount:count}); } catch (_) {}};
    async function load() {
      const archive = await read();
      if (archive?.version !== 1 || !Array.isArray(archive.records)) throw Error('GOE_ARCHIVE_FORMAT');
      const fresh = new Map();
      for (const r of archive.records) {
        if (r.kind !== 'note') continue;
        if (typeof r.id !== 'string' || !r.id || !Number.isFinite(r.timestamp_ms) || typeof r.is_sent !== 'boolean') throw Error('GOE_ARCHIVE_RECORD');
        const id = PREFIX + r.id;
        if (fresh.has(id)) throw Error('GOE_ARCHIVE_DUPLICATE');
        fresh.set(id, r);
      }
      records = fresh;
      return [...fresh].map(([id,r]) => ({id,r}));
    }
    function response(id, r) {
      return {directMessageId:id, sequenceId:'0', isIncoming:!r.is_sent,
        originBoxId:r.is_sent ? 2 : 1, boxId:r.is_sent ? 2 : 1,
        type:0, title:'[GOE] ' + (r.title || '(제목 없음)'), senderId:'',
        hasAttachment:false, hasInlineAttachment:false, isDelegate:false,
        isDelegateOrigin:false, isRead:true, isReply:false, isForward:false,
        sentTime:r.timestamp_ms, receiverList:[], localName:r.sender_name || 'GOE 원본',
        globalName:r.sender_name || 'GOE 원본', nickName:r.sender_name || 'GOE 원본',
        plainContents:String(r.content || ''),
        contents:'<div style="white-space:pre-wrap">' + escapeHTML(r.content || '') + '</div>' +
          (r.receiver_label ? '<p>원본 수신 대상: ' + escapeHTML(r.receiver_label) + '</p>' : '')};
    }
    const isSupportedBox = box => Number(box) === 1 || Number(box) === 2;
    function ordered(rows) {
      return rows.slice().sort((a,b) => Number(b.sentTime) - Number(a.sentTime) ||
        (localId(a.dmId) - localId(b.dmId)) || String(a.dmId).localeCompare(String(b.dmId)));
    }
    async function page(original, self, box, cursor, rest) {
      if (!isSupportedBox(box)) return original.call(self, box, cursor, ...rest);
      let session = sessions.get(String(box));
      if (!cursor) {
        let local;
        try {local = await load();} catch (_) {
          notify('NATIVE_FAILED', 0);
          return original.call(self, box, cursor, ...rest);
        }
        session = {b:[], a:local.filter(({r}) => (r.is_sent ? 2 : 1) === Number(box)).map(({id,r}) => new (getVM())(response(id,r))),
          offsets:new Map(), remoteCursor:undefined, done:false, total:0, result:false, lastNative:undefined};
        sessions.set(String(box), session);
      }
      if (!session || (cursor && !session.offsets.has(cursor))) {
        // Never forward an unknown local cursor into a remote manager.
        if (localId(cursor)) return {dmList:[],total:session?.total || 0,result:false};
        return original.call(self, box, cursor, ...rest);
      }
      const offset = cursor ? session.offsets.get(cursor) : 0;
      const end = offset + pageSize;
      for (;;) {
        const merged = ordered([...session.b, ...session.a]);
        const cutoff = merged[end - 1];
        const oldestB = session.b[session.b.length - 1];
        // A remote page is newest-first. Fetch until unseen B cannot precede the cutoff.
        const enough = session.done || (cutoff && oldestB && Number(cutoff.sentTime) > Number(oldestB.sentTime));
        if (enough) break;
        const native = await original.call(self, box, session.remoteCursor, ...rest);
        if (!native || !Array.isArray(native.dmList)) throw Error('GOE_NATIVE_LIST_FORMAT');
        session.lastNative = native;
        session.result = Boolean(native.result);
        session.total = Number(native.total) || session.total;
        const ids = new Set(session.b.map(r => r.dmId));
        const added = native.dmList.filter(r => !ids.has(r.dmId));
        session.b.push(...added);
        const tail = native.dmList[native.dmList.length - 1]?.dmId;
        session.done = native.dmList.length < pageSize || !tail || tail === session.remoteCursor || added.length === 0 || (session.total > 0 && session.b.length >= session.total);
        session.remoteCursor = tail;
      }
      const dmList = ordered([...session.b, ...session.a]).slice(offset, end);
      if (dmList.length) session.offsets.set(dmList[dmList.length - 1].dmId, offset + dmList.length);
      notify('NATIVE_LIST', dmList.filter(r => localId(r.dmId)).length);
      return {...session.lastNative, dmList,total:session.total + session.a.length,
        result:session.result || session.a.length > 0};
    }
    function wrap(key, original) {
      // Read-only search has its own local merge and cursor guard.
      if (key === 'nx' || key === 'vS') return original;
      if (key === 'F0') return function(box,cursor,...rest) {return page(original,this,box,cursor,rest);};
      if (key === '_V') return async function(request,...rest) {
        if (!localId(request?.dmId)) return original.call(this,request,...rest);
        if (!records.has(request.dmId)) await load();
        const r = records.get(request.dmId);
        if (!r) return undefined;
        notify('NATIVE_DETAIL',1);
        const detail = new (getDetailVM())(response(request.dmId,r));
        detail.goeReceiverNames = Array.isArray(r.recipient_labels) ? r.recipient_labels : (r.receiver_label ? [r.receiver_label] : []);
        return detail;
      };
      // Reply/forward sagas use wm to assemble a new compose model. Local notes are read-only.
      if (key === 'wm') return function(...args) {
        if (containsLocal(args)) return Promise.resolve({dm:undefined,dmContent:undefined,receiverList:undefined});
        return original.apply(this,args);
      };
      return function(...args) {
        if (containsLocal(args)) return Promise.reject(Object.assign(Error('GOE_ARCHIVE_READ_ONLY'), {code:'GOE_ARCHIVE_READ_ONLY'}));
        return original.apply(this,args);
      };
    }
    return {wrap, containsLocal, response};
  }
  function wrapFactory(factory, options) {
    return function(module, exports, req) {
      const hooks = makeHooks({...options, getVM:() => req(55175).I, getDetailVM:() => req(24386).J});
      const stable = new Map();
      const intercepted = new Proxy(req, {get(target,key) {
        if (key !== 'd') return Reflect.get(target,key);
        return function(targetExports, definitions) {
          if (targetExports !== exports) return req.d(targetExports,definitions);
          const wrapped = {};
          for (const [name,getter] of Object.entries(definitions)) wrapped[name] = function() {
            const value = getter();
            if (typeof value !== 'function') return value;
            if (!stable.has(name) || stable.get(name).original !== value) stable.set(name,{original:value,value:hooks.wrap(name,value)});
            return stable.get(name).value;
          };
          return req.d(targetExports,wrapped);
        };
      }});
      factory(module,exports,intercepted);
      try {options.report?.({status:'NATIVE_READY',recordCount:0});} catch (_) {}
    };
  }
  function install(root) {
    if (root.__goeNativeFactoryHook) return false;
    const bridge = root.__goeNativeArchive;
    if (!bridge || typeof bridge.read !== 'function') return false;
    const chunks = root[CHUNK] ||= [];
    const decorate = chunk => {
      if (chunk?.[1]?.[MANAGER] && !chunk[1][MANAGER].__goeWrapped) {
        const wrapped = wrapFactory(chunk[1][MANAGER],{read:() => bridge.read(),report:v => bridge.report?.(v)});
        wrapped.__goeWrapped = true;
        chunk[1][MANAGER] = wrapped;
      }
      return chunk;
    };
    chunks.forEach(decorate);
    const push = chunks.push;
    chunks.push = function(...entries) {return push.apply(this, entries.map(decorate));};
    root.__goeNativeFactoryHook = true;
    return true;
  }
  return {install,wrapFactory,makeHooks,containsLocal,escapeHTML,PREFIX,CHUNK};
});
