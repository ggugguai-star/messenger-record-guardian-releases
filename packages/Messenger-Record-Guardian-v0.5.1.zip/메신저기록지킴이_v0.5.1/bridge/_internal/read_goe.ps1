param([Parameter(Mandatory=$true)][string]$BackupPath)
$ErrorActionPreference = 'Stop'
# Internal adapter. The caller receives sensitive content on stdout; do not log it.
if ([IntPtr]::Size -ne 4) { throw '32-bit PowerShell required' }
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class ReadGoeSqlite {
 [DllImport("kernel32.dll", CharSet=CharSet.Unicode)] public static extern bool SetDllDirectory(string path);
 [DllImport("sqlite3.dll", CallingConvention=CallingConvention.Cdecl)] public static extern int sqlite3_open_v2(byte[] path, out IntPtr db, int flags, IntPtr vfs);
 [DllImport("sqlite3.dll", CallingConvention=CallingConvention.Cdecl)] public static extern int sqlite3_key(IntPtr db, byte[] key, int size);
 [DllImport("sqlite3.dll", CallingConvention=CallingConvention.Cdecl)] public static extern int sqlite3_prepare_v2(IntPtr db, byte[] sql, int len, out IntPtr stmt, IntPtr tail);
 [DllImport("sqlite3.dll", CallingConvention=CallingConvention.Cdecl)] public static extern int sqlite3_step(IntPtr stmt);
 [DllImport("sqlite3.dll", CallingConvention=CallingConvention.Cdecl)] public static extern IntPtr sqlite3_column_text(IntPtr stmt, int col);
 [DllImport("sqlite3.dll", CallingConvention=CallingConvention.Cdecl)] public static extern int sqlite3_column_bytes(IntPtr stmt, int col);
 [DllImport("sqlite3.dll", CallingConvention=CallingConvention.Cdecl)] public static extern int sqlite3_finalize(IntPtr stmt);
 [DllImport("sqlite3.dll", CallingConvention=CallingConvention.Cdecl)] public static extern int sqlite3_close(IntPtr db);
}
'@
$app = 'C:\Program Files (x86)\AtMessenger7'
$exe = Join-Path $app 'AtMessengerMobileEdition.exe'
$hashStream = [IO.File]::OpenRead($exe); $sha = [Security.Cryptography.SHA256]::Create()
try { $exeHash = [BitConverter]::ToString($sha.ComputeHash($hashStream)).Replace('-','') } finally { $hashStream.Dispose(); $sha.Dispose() }
if ($exeHash -ne 'ABE762F5B76D7F926B3E1A9AE7BE1574FDE456DE2DF2C403AEDF00D9A88523EE') { throw 'Unsupported GOE version' }
if (!(Test-Path -LiteralPath $BackupPath -PathType Leaf)) { throw 'Backup not found' }
$stream = [IO.File]::OpenRead($exe)
try { [void]$stream.Seek(7334756, [IO.SeekOrigin]::Begin); $key = New-Object byte[] 8; if ($stream.Read($key,0,8) -ne 8) { throw 'Key source unavailable' } } finally { $stream.Dispose() }
[void][ReadGoeSqlite]::SetDllDirectory($app)
$db = [IntPtr]::Zero
$rc = [ReadGoeSqlite]::sqlite3_open_v2([Text.Encoding]::UTF8.GetBytes((Resolve-Path -LiteralPath $BackupPath).Path + [char]0), [ref]$db, 1, [IntPtr]::Zero)
if ($rc -ne 0) { if ($db -ne [IntPtr]::Zero) { [void][ReadGoeSqlite]::sqlite3_close($db) }; throw "Open failed: $rc" }
try {
 if ([ReadGoeSqlite]::sqlite3_key($db, $key, $key.Length) -ne 0) { throw 'Key setup failed' }
 $sql = 'SELECT sChatId,sRoomId,sTalkerId,sTalkerName,sTalkDate,sTalkerContent,sOwnerId,sDeleted,sOriginalFileName FROM tblChatContent ORDER BY sRoomId,sTalkDate,sChatId'
 $stmt = [IntPtr]::Zero
 $rc = [ReadGoeSqlite]::sqlite3_prepare_v2($db,[Text.Encoding]::UTF8.GetBytes($sql+[char]0),-1,[ref]$stmt,[IntPtr]::Zero)
 if ($rc -ne 0) { throw "Read failed: $rc" }
 try {
  $rows = [Collections.Generic.List[object]]::new()
  while (($rc = [ReadGoeSqlite]::sqlite3_step($stmt)) -eq 100) {
   $values = @(); for ($i=0; $i -lt 9; $i++) {
    $ptr=[ReadGoeSqlite]::sqlite3_column_text($stmt,$i); $n=[ReadGoeSqlite]::sqlite3_column_bytes($stmt,$i)
    if ($ptr -eq [IntPtr]::Zero) { $values += $null } else { $b=New-Object byte[] $n; if($n){[Runtime.InteropServices.Marshal]::Copy($ptr,$b,0,$n)}; $values += [Text.Encoding]::UTF8.GetString($b) }
   }
   $rows.Add([ordered]@{message_id=$values[0];room_id=$values[1];sender_id=$values[2];sender_name=$values[3];timestamp=$values[4];content=$values[5];owner_id=$values[6];deleted=$values[7];attachment_name=$values[8]})
  }
  if($rc -ne 101){throw "Read iteration failed: $rc"}
 } finally { [void][ReadGoeSqlite]::sqlite3_finalize($stmt) }
 $noteSql = 'SELECT sMsgId,sSenderId,sSenderName,sDate,cIsSend,sSubject,sContent,sReceivers,sOwnerId,sAttachOriginal,sDeleted,sAttach,cRead,sReceiverNames,sHiddenReceivers,sReservedDate FROM tblMessage ORDER BY sDate,sMsgId'
 $noteStmt = [IntPtr]::Zero
 $rc = [ReadGoeSqlite]::sqlite3_prepare_v2($db,[Text.Encoding]::UTF8.GetBytes($noteSql+[char]0),-1,[ref]$noteStmt,[IntPtr]::Zero)
 if ($rc -ne 0) { throw "Note read failed: $rc" }
 try {
  $notes = [Collections.Generic.List[object]]::new()
  while (($rc = [ReadGoeSqlite]::sqlite3_step($noteStmt)) -eq 100) {
   $values=@(); for ($i=0; $i -lt 16; $i++) {
    $ptr=[ReadGoeSqlite]::sqlite3_column_text($noteStmt,$i); $n=[ReadGoeSqlite]::sqlite3_column_bytes($noteStmt,$i)
    if ($ptr -eq [IntPtr]::Zero) { $values += $null } else { $b=New-Object byte[] $n; if($n){[Runtime.InteropServices.Marshal]::Copy($ptr,$b,0,$n)}; $values += [Text.Encoding]::UTF8.GetString($b) }
   }
   $notes.Add([ordered]@{message_id=$values[0];sender_id=$values[1];sender_name=$values[2];timestamp=$values[3];is_sent=$values[4];subject=$values[5];content=$values[6];receivers=$values[7];owner_id=$values[8];attachments=$values[9];deleted=$values[10];attachment_paths=$values[11];read_state=$values[12];receiver_names=$values[13];hidden_receivers=$values[14];reserved_date=$values[15]})
  }
  if($rc -ne 101){throw "Note iteration failed: $rc"}
 } finally { [void][ReadGoeSqlite]::sqlite3_finalize($noteStmt) }
 $roomSql='SELECT sRoomId,sRoomName,sUserIds,sUserNames,sOwnerId,sDeleted FROM tblChatRoomInfo ORDER BY sRoomId'
 $roomStmt=[IntPtr]::Zero
 $rc=[ReadGoeSqlite]::sqlite3_prepare_v2($db,[Text.Encoding]::UTF8.GetBytes($roomSql+[char]0),-1,[ref]$roomStmt,[IntPtr]::Zero)
 if($rc -ne 0){throw "Room read failed: $rc"}
 try {
  $rooms=[Collections.Generic.List[object]]::new()
  while(($rc=[ReadGoeSqlite]::sqlite3_step($roomStmt)) -eq 100){
   $values=@(); for($i=0;$i -lt 6;$i++){
    $ptr=[ReadGoeSqlite]::sqlite3_column_text($roomStmt,$i);$n=[ReadGoeSqlite]::sqlite3_column_bytes($roomStmt,$i)
    if($ptr -eq [IntPtr]::Zero){$values+=$null}else{$b=New-Object byte[] $n;if($n){[Runtime.InteropServices.Marshal]::Copy($ptr,$b,0,$n)};$values+=[Text.Encoding]::UTF8.GetString($b)}
   }
   $rooms.Add([ordered]@{room_id=$values[0];name=$values[1];user_ids=$values[2];user_names=$values[3];owner_id=$values[4];deleted=$values[5]})
  }
  if($rc -ne 101){throw "Room iteration failed: $rc"}
 } finally {[void][ReadGoeSqlite]::sqlite3_finalize($roomStmt)}
 [Console]::Out.Write(([ordered]@{chats=@($rows.ToArray());notes=@($notes.ToArray());rooms=@($rooms.ToArray())} | ConvertTo-Json -Depth 5 -Compress))
} finally { [Array]::Clear($key,0,$key.Length); [void][ReadGoeSqlite]::sqlite3_close($db) }
