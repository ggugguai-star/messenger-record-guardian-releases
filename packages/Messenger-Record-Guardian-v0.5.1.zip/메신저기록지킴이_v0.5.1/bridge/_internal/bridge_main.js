// GOE local archive extension main handler. No messages or credentials handled.
;(()=>{try{
 const {ipcMain,app}=require('electron'),{execFile}=require('child_process'),fs=require('fs'),path=require('path');
 const service=__GOE_SERVICE_PATH__,dir=path.join(process.env.LOCALAPPDATA,'GOEBrityBridge');
 ipcMain.handle('goe-local-archive-read',()=>new Promise((resolve,reject)=>{
  execFile(service,['--read'],{windowsHide:true,encoding:'utf8',maxBuffer:64*1024*1024,timeout:60000},(error,out)=>{
   if(error){reject(Error('archive_read_failed'));return;}
   try{const value=JSON.parse(out.replace(/^\uFEFF/,''));if(value.version!==1||!Array.isArray(value.records))throw Error();resolve(value);}catch(_){reject(Error('archive_format_failed'));}
  });
 }));
 ipcMain.on('goe-local-archive-status',(_,value)=>{try{const allowed=['MOUNTED','READY','READ_FAILED','FORMAT_FAILED','NATIVE_READY','NATIVE_FAILED','NATIVE_LIST','NATIVE_DETAIL','NATIVE_SEARCH','NATIVE_SEARCH_FAILED'];if(!allowed.includes(value?.status))return;fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'extension-status.json'),JSON.stringify({time:new Date().toISOString(),status:value.status,recordCount:Number.isSafeInteger(value.recordCount)?value.recordCount:null}));}catch(_){}});
 const nativeCode=__GOE_NATIVE_CODE__;
 const attach=contents=>{contents.on('did-finish-load',()=>{contents.executeJavaScript(nativeCode).catch(()=>{});});};
 app.on('web-contents-created',(_,contents)=>attach(contents));
}catch(_){}})();
