/* Brity 2.1.98 local search add-on. Run before 4902.prod.js registers module 59165.
 * Uses the existing local archive bridge; no IPC, files, credentials or server API here.
 */
(function(root,build){const api=build();if(typeof module==='object'&&module.exports)module.exports=api;else api.install(root);})(globalThis,function(){
  'use strict';
  const PREFIX='goe-local:', CHUNK='webpackChunkbrity_teams_desktop_client';
  const ownId=value=>typeof value==='string'&&value.startsWith(PREFIX);
  const fold=value=>String(value??'').normalize('NFC').toLocaleLowerCase('ko-KR');
  const fields=['dmId','sequenceId','boxId','senderId','title','plainContents','receiverId','sentTime','isDelegate','sendStatus','isRead','isForward','hasAttachment','isReply','isFail','type','localName','globalName','nickName','companyName','englishCompanyName','departmentName','englishDepartmentName','jobPositionName','englishJobPositionName','profileUrl'];
  function makeSearchVM(req,r){
    // The original internal search class is not exported. Its complete public field
    // contract and VM marker are reproduced on an original installed base VM.
    const value=new (req(55175).I)({directMessageId:PREFIX+r.id,sequenceId:'0',originBoxId:r.is_sent?2:1,
      isIncoming:!r.is_sent,type:0,title:'[GOE] '+(r.title||'(제목 없음)'),senderId:'',sentTime:r.timestamp_ms,
      isDelegate:false,isDelegateOrigin:false,isRead:true,isReply:false,isForward:false,isFail:false,
      hasAttachment:false,hasInlineAttachment:false,receiverList:[],localName:r.sender_name||'GOE 원본',
      globalName:r.sender_name||'GOE 원본',nickName:r.sender_name||'GOE 원본',companyName:null,
      englishCompanyName:null,departmentName:null,englishDepartmentName:null,jobPositionName:null,
      englishJobPositionName:null,profileUrl:null});
    value.VMType=req(56183).D.DirectMessageSearchResultVM;
    value.plainContents=String(r.content||'');value.receiverId='';
    return value;
  }
  function matches(r,request){
    const terms=fold(request.basicCondition?.keyword).trim().split(/\s+/).filter(Boolean);
    const haystack=[r.sender_name,r.title,r.content].map(fold).join('\n');
    if(!terms.every(t=>haystack.includes(t)))return false;
    const filter=request.filter||{},sender=fold(filter.senderKeyword).trim();
    if(sender&&!fold(r.sender_name).includes(sender))return false;
    if(filter.boxId!==undefined&&filter.boxId!==null&&filter.boxId!==''&&Number(filter.boxId)!==0&&Number(filter.boxId)!==(r.is_sent?2:1))return false;
    if(filter.fileInclude==='INCLUDE')return false;
    const start=Number(filter.period?.startDate),end=Number(filter.period?.endDate);
    if(filter.period?.startDate&&Number.isFinite(start)&&r.timestamp_ms<start)return false;
    if(filter.period?.endDate&&Number.isFinite(end)){
      const day=new Date(end);day.setHours(23,59,59,999);
      if(r.timestamp_ms>day.getTime())return false;
    }
    return true;
  }
  function createHooks({read,report=()=>{},makeVM}){
    const sessions=new Map();
    const notify=(status,count)=>{try{report({status,recordCount:count});}catch(_){}};
    const queryKey=(key,r)=>JSON.stringify([key,r.basicCondition?.keyword||'',!!r.basicCondition?.isDetailMessage,r.filter||null]);
    async function localResults(request){
      const data=await read();if(data?.version!==1||!Array.isArray(data.records))throw Error('GOE_SEARCH_ARCHIVE_FORMAT');
      const seen=new Map(),selected=[];
      for(const r of data.records){
        if(r.kind!=='note')continue;
        if(typeof r.id!=='string'||!r.id||typeof r.is_sent!=='boolean'||!Number.isFinite(r.timestamp_ms))throw Error('GOE_SEARCH_RECORD');
        if(seen.has(r.id)){
          const old=seen.get(r.id);
          if(['title','content','sender_name','timestamp_ms','is_sent'].some(k=>old[k]!==r[k]))throw Error('GOE_SEARCH_ID_COLLISION');
          continue;
        }
        seen.set(r.id,r);if(matches(r,request))selected.push(r);
      }
      return selected.sort((a,b)=>b.timestamp_ms-a.timestamp_ms||a.id.localeCompare(b.id)).map(makeVM);
    }
    function remoteRequest(request,page){
      const basic={...request.basicCondition,page};
      // EC ignores fromDMId, but the existing native-dm guard rightly blocks local IDs.
      if(ownId(basic.fromDMId))delete basic.fromDMId;
      return {...request,basicCondition:basic};
    }
    function wrap(key,original){
      if(key!=='nx'&&key!=='vS')return original;
      return async function(request,...rest){
        if(!request||typeof request!=='object')return original.call(this,request,...rest);
        const page=Math.max(1,Number(request.basicCondition?.page)||1),size=key==='vS'?10:50;
        const q=queryKey(key,request);let s=sessions.get(q);
        if(page===1||!s){
          let a;try{a=await localResults(request);}catch(_){notify('NATIVE_SEARCH_FAILED',0);return original.call(this,remoteRequest(request,page),...rest);}
          s={a,b:[],seen:new Set(),next:1,count:0,done:false,last:undefined};sessions.set(q,s);
          if(sessions.size>8)sessions.delete(sessions.keys().next().value);
        }
        const end=page*size;
        // Always obtain native page 1 so its count and B result are retained.
        while(!s.done&&(s.next===1||s.a.length+s.b.length<end)){
          const native=await original.call(this,remoteRequest(request,s.next),...rest);
          if(!native||!Array.isArray(native.list))throw Error('GOE_SEARCH_NATIVE_FORMAT');
          s.last=native;s.count=Math.max(0,Number(native.count)||0);
          let added=0;
          for(const row of native.list){
            const id=JSON.stringify([row.dmId,row.boxId,row.sequenceId]);
            if(!s.seen.has(id)&&!s.a.some(a=>a.dmId===row.dmId&&a.boxId===row.boxId&&a.sequenceId===row.sequenceId)){
              s.seen.add(id);s.b.push(row);added++;
            }
          }
          s.done=native.list.length===0||added===0||native.list.length<size||s.b.length>=s.count;
          s.next++;
        }
        // Local matches precede B; B objects and server ranking are kept intact.
        const list=s.a.concat(s.b).slice((page-1)*size,end);
        notify('NATIVE_SEARCH',list.filter(r=>ownId(r.dmId)).length);
        return {...s.last,list,count:s.count+s.a.length};
      };
    }
    return {wrap,localResults};
  }
  function wrapFactory(factory,options){
    return function(module,exports,req){
      const hooks=createHooks({...options,makeVM:r=>makeSearchVM(req,r)}),stable=new Map();
      const proxy=new Proxy(req,{get(target,key){
        if(key!=='d')return Reflect.get(target,key);
        return function(targetExports,definitions){
          if(targetExports!==exports)return req.d(targetExports,definitions);
          const out={...definitions};
          for(const name of ['nx','vS'])if(definitions[name])out[name]=()=>{
            const original=definitions[name]();
            if(!stable.has(name)||stable.get(name).original!==original)stable.set(name,{original,value:hooks.wrap(name,original)});
            return stable.get(name).value;
          };
          return req.d(targetExports,out);
        };
      }});
      return factory(module,exports,proxy);
    };
  }
  function install(root){
    if(root.__goeNativeSearchHook)return false;
    const bridge=root.__goeNativeArchive;if(!bridge||typeof bridge.read!=='function')return false;
    const chunks=root[CHUNK]||=[];
    const decorate=entry=>{
      const original=entry?.[1]?.[59165];if(original&&!original.__goeSearchWrapped){
        const wrapped=wrapFactory(original,{read:()=>bridge.read(),report:e=>bridge.report?.(e)});
        wrapped.__goeSearchWrapped=true;entry[1][59165]=wrapped;
      }
      return entry;
    };
    chunks.forEach(decorate);const push=chunks.push;
    chunks.push=function(...entries){return push.apply(this,entries.map(decorate));};
    root.__goeNativeSearchHook=true;return true;
  }
  return {install,wrapFactory,createHooks,makeSearchVM,matches,fields,PREFIX,CHUNK};
});
