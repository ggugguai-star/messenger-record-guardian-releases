// GOE local archive extension. Runs in preload's isolated world; no server API.
;(() => {
  try {
    const {ipcRenderer,contextBridge}=require('electron');
    const state=value=>{try{ipcRenderer.send('goe-local-archive-status',value)}catch(_){}};
    let closeRecipients;
    async function showRecipients(dmId){
      if(typeof dmId!=='string'||!dmId.startsWith('goe-local:'))return;
      let names=[];
      try{
        const data=await ipcRenderer.invoke('goe-local-archive-read');
        const record=data.records.find(r=>'goe-local:'+r.id===dmId&&r.kind==='note');
        if(!record)return;
        names=Array.isArray(record.recipient_labels)?record.recipient_labels:(record.receiver_label?[record.receiver_label]:[]);
      }catch(_){return;}
      closeRecipients?.();
      const host=document.createElement('div');host.id='goe-original-recipients';
      const root=host.attachShadow({mode:'closed'});
      root.innerHTML=`<style>:host{all:initial}*{box-sizing:border-box;font-family:'Malgun Gothic',sans-serif}.shade{position:fixed;inset:0;background:#0009;z-index:2147483647;display:flex;align-items:center;justify-content:center}.dialog{width:min(560px,92vw);max-height:80vh;background:white;border-radius:8px;color:#20242a;box-shadow:0 8px 32px #0004;padding:22px;display:flex;flex-direction:column}header{display:flex;align-items:center;gap:12px}h2{font-size:18px;margin:0;flex:1}button{font:inherit;cursor:pointer;border:0;border-radius:5px;padding:8px 18px;background:#3183ed;color:white}.close{background:white;color:#555;font-size:22px;padding:0 5px}.hint{font-size:12px;color:#677586;margin:14px 0}.list{overflow:auto;margin:0 0 20px;padding:0;list-style:none}.list li{font-size:14px;line-height:1.65;padding:12px 0;border-bottom:1px solid #edf0f3;white-space:pre-wrap;overflow-wrap:anywhere}footer{text-align:right}</style><div class="shade"><section class="dialog" role="dialog" aria-modal="true" aria-labelledby="title"><header><h2 id="title"></h2><button class="close" aria-label="닫기">×</button></header><p class="hint">GOE 백업의 원본 수신 대상입니다. 현재 Brity 계정과 연결하지 않고 이름과 부서 표기를 보존합니다.</p><ul class="list"></ul><footer><button class="ok">확인</button></footer></section></div>`;
      root.getElementById('title').textContent=`수신 대상 (${names.length}) · GOE 원본`;
      const list=root.querySelector('.list');
      for(const label of names){const item=document.createElement('li');item.textContent=String(label);list.append(item);}
      if(!names.length){const item=document.createElement('li');item.textContent='백업에 수신 대상 정보가 없습니다.';list.append(item);}
      const dismiss=()=>{document.removeEventListener('keydown',onKey,true);host.remove();closeRecipients=undefined;};
      const onKey=event=>{if(event.key==='Escape'){event.stopPropagation();dismiss();}else if(event.key==='Tab'){event.preventDefault();const buttons=[...root.querySelectorAll('button')];const current=buttons.indexOf(root.activeElement);buttons[(current+(event.shiftKey?-1:1)+buttons.length)%buttons.length].focus();}};
      root.querySelector('.close').onclick=dismiss;root.querySelector('.ok').onclick=dismiss;
      root.querySelector('.shade').onclick=event=>{if(event.target===root.querySelector('.shade'))dismiss();};
      closeRecipients=dismiss;document.addEventListener('keydown',onKey,true);document.body.append(host);root.querySelector('.ok').focus();
    }
    try{contextBridge.exposeInMainWorld('__goeNativeArchive',{
      read:()=>ipcRenderer.invoke('goe-local-archive-read'),
      showRecipients,
      report:value=>{state(value);if(value?.status==='NATIVE_READY'){const h=document.getElementById('goe-local-archive-extension');if(h)h.style.display='none';}}
    });}catch(_){}
  } catch (_) { /* Keep original Brity functionality available if unsupported. */ }
})();
